#include "unittest/ut_test.h"
#include "pk2aufgabe5.h"

int gValues[] = { 19, 73, 102, 1, 23, 45};

UT_TEST(IsEmptyBeforePush)
{
	CDoubleLinkedList list;
	UT_CHECK(list.IsEmpty() == true);
}

UT_TEST(GetElementCountBeforePush)
{
	CDoubleLinkedList list;
	UT_CHECK(list.GetElementCount() == 0);
}

UT_TEST(GetFrontBeforePush)
{
	CDoubleLinkedList list;
	UT_CHECK(list.GetFront() == nullptr);
}

UT_TEST(PushBack)
{
	CDoubleLinkedList list;

	UT_CHECK(list.IsEmpty() == true);
	UT_CHECK(list.GetElementCount() == 0);
	UT_CHECK(list.GetFront() == nullptr);


	for(int Index = 0; Index < std::size(gValues); ++ Index)
	{
		list.PushBack(gValues[Index]);

		UT_CHECK(list.IsEmpty() == false);
		UT_CHECK(list.GetElementCount() == Index + 1);

		// TODO: Check if the list next and previous are correct
	}
}