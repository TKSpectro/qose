#pragma once

void Aufgabe2(int _Index, int* _pResult);